# Soil-Verity
SoilVerity: Field Shift tool that compares crop rotations using NASA Earth data, soil tests and farmer priorities, and shows how far to trust each recommendation.

## Data layer (backend/app/data, owner: Bala)
Fetches NASA POWER, GPM IMERG, SMAP L4 and MERRA-2 for a farm location, caches small Parquet files, and returns one daily table per source (not merged) so the decision engine can re-run scoring per source. See `contracts/data_contract.md`.
Status: POWER client done; IMERG, SMAP, MERRA-2 and MODIS fetchers are stubs. `use_fixture=True` returns synthetic, flagged data for development.
Run tests: `cd backend && pip install -r requirements.txt && python -m pytest tests -q`
