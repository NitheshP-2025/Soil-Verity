# Data layer contract (owner: Bala) — agree on day 1

```python
from app.data import get_features
bundle = get_features(lat, lon, start_year=2005, end_year=2024,
                      sources=("power","imerg","smap","merra2"),
                      offline=False, use_fixture=False)
```

Returns `FeatureBundle`:
- `bundle.daily[source]` -> pandas DataFrame, one row per day, columns:
  `date, rain_mm, temp_mean_c, temp_max_c, solar_mj_m2, rh_pct, wind_ms, soil_moisture`
  (a source fills only what it provides; the rest are NaN). Sources are NOT merged.
- `bundle.meta[source]` -> status (`ok` | `fallback` | `unavailable`), dataset, version, date range,
  grid cell, cache_hit, is_fallback, note. Swetha: pass `bundle.meta_dict()` into the card's limits note.
- `bundle.available()` -> sources that returned data.

Helpers in `app.data.features`: `monthly_summary(df)`, `extreme_events(df)`, `annual_rain_disagreement(a, b)`.

## Who needs what
- **Nithesh:** call `get_features(..., use_fixture=True)` today. Fixture sources deliberately disagree
  (IMERG wetter, MERRA-2 biased) so Solid/Mixed/Fragile can be tested. Run scoring once per source in `available()`.
  Tell Bala which features/aggregations you need and the extreme-event thresholds (see `config.py`, placeholders).
- **Swetha:** `get_features` is synchronous and reads Parquet; first uncached call can be slow, so use the
  pre-fetch script for the pilot district and `offline=True` on the demo server.
- **Jagadeesh:** thresholds and coverage notes (e.g. SMAP record is shorter than 20 years) feed the limits text.
- **Sriram:** nothing direct; the climate picture comes through Swetha's API (yearly extremes, monthly summaries).

Fixture data is synthetic and always flagged `is_fallback=True`. Never show it as real NASA data.
