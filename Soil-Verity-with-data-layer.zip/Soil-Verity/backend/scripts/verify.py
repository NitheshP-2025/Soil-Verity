"""One-command health check of the data layer.
  python -m scripts.verify            # offline checks + LIVE NASA POWER call
  python -m scripts.verify --offline  # skip the live call
"""
import sys, tempfile, time
from app.data import get_features
from app.data.features import extreme_events, monthly_summary

offline = "--offline" in sys.argv
ok = True
def check(name, cond, detail=""):
    global ok
    ok &= bool(cond)
    print(("PASS" if cond else "FAIL"), name, detail)

# 1. fixture path (no network)
b = get_features(10.78, 79.14, 2018, 2022, use_fixture=True)
check("fixture: 4 sources, flagged synthetic", len(b.available()) == 4 and all(m.is_fallback for m in b.meta.values()))
check("features: extremes + monthly", len(extreme_events(b.daily["power"])) == 5 and len(monthly_summary(b.daily["power"])) == 60)

# 2. live POWER (Thanjavur area), with cache check
if not offline:
    with tempfile.TemporaryDirectory() as tmp:
        t = time.time()
        b1 = get_features(10.78, 79.14, 2020, 2023, sources=("power",), cache_root=tmp)
        m = b1.meta["power"]
        check("live POWER fetched", m.status == "ok" and not m.cache_hit, f"({time.time()-t:.1f}s) {m.note}")
        if m.status == "ok":
            df = b1.daily["power"]
            check("POWER rows ~ 4 years of days", 1400 <= len(df) <= 1470, f"rows={len(df)}")
            check("rain plausible (0-500 mm/day, 300-3000 mm/yr)", df.rain_mm.max() < 500 and 300 < df.rain_mm.sum() / 4 < 3000,
                  f"mean annual={df.rain_mm.sum()/4:.0f} mm")
            check("temp plausible (15-45 C)", df.temp_mean_c.between(15, 45).all(), f"range={df.temp_mean_c.min():.1f}..{df.temp_mean_c.max():.1f}")
            check("fill values removed", not (df.select_dtypes('number') <= -900).any().any())
            b2 = get_features(10.80, 79.20, 2020, 2023, sources=("power",), cache_root=tmp, offline=True)
            check("cache reused for nearby farm (offline)", b2.meta["power"].cache_hit and b2.meta["power"].status == "ok")
            print("solar sample (check units vs POWER docs):", round(df.solar_mj_m2.mean(), 2))
print("\nALL CHECKS PASSED" if ok else "\nSOME CHECKS FAILED")
