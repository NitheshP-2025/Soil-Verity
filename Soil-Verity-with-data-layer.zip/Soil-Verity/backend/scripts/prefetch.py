"""Pre-fill the Parquet cache for the pilot district so the demo works offline.

Run from backend/:  python -m scripts.prefetch --points points.csv --start 2005 --end 2024
points.csv columns: name,lat,lon   (a handful of grid points covering the pilot district)
Sources that are not implemented yet are skipped and reported.
"""
import argparse, csv
from app.data import get_features


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--points", required=True)
    ap.add_argument("--start", type=int, default=2005)
    ap.add_argument("--end", type=int, default=2024)
    a = ap.parse_args()
    with open(a.points, newline="") as f:
        for row in csv.DictReader(f):
            b = get_features(float(row["lat"]), float(row["lon"]), a.start, a.end)
            print(row["name"], {s: (m.status, m.note) for s, m in b.meta.items()})


if __name__ == "__main__":
    main()
