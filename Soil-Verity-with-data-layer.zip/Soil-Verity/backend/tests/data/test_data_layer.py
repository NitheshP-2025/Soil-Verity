import numpy as np
from app.data import get_features, cache
from app.data.features import extreme_events, monthly_summary, annual_rain_disagreement
from app.data.sources.power import parse_power_json


def _payload():
    days = {"20240101": 0.0, "20240102": 70.0, "20240103": -999.0}
    return {"properties": {"parameter": {
        "PRECTOTCORR": days, "T2M": {k: 27.0 for k in days}, "T2M_MAX": {k: 39.0 for k in days}}}}


def test_power_parse_handles_fill_and_columns():
    df = parse_power_json(_payload())
    assert list(df.columns)[0] == "date" and len(df) == 3
    assert np.isnan(df["rain_mm"].iloc[2])
    assert df["rain_mm"].iloc[1] == 70.0


def test_cache_snaps_nearby_points_to_one_file(tmp_path):
    a = cache.cache_path("power", 10.78, 79.14, 2005, 2024, tmp_path)
    b = cache.cache_path("power", 10.90, 79.20, 2005, 2024, tmp_path)
    assert a == b


def test_fixture_bundle_has_disagreeing_sources():
    b = get_features(10.78, 79.14, 2018, 2022, use_fixture=True)
    assert set(b.available()) == {"power", "imerg", "smap", "merra2"}
    assert all(m.is_fallback for m in b.meta.values())
    d = annual_rain_disagreement(b.daily["power"], b.daily["imerg"])
    assert (d["rel_diff"].abs() > 0.05).all()


def test_features_extremes_and_monthly():
    b = get_features(10.78, 79.14, 2018, 2019, use_fixture=True)
    ev = extreme_events(b.daily["power"])
    assert list(ev["year"]) == [2018, 2019] and (ev["longest_dry_spell_days"] > 0).all()
    ms = monthly_summary(b.daily["power"])
    assert len(ms) == 24


def test_offline_without_cache_marks_unavailable(tmp_path):
    b = get_features(10.78, 79.14, 2018, 2019, offline=True, cache_root=tmp_path)
    assert b.available() == [] and all("offline" in m.note for m in b.meta.values())
