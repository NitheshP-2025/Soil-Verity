"""The data-layer contract. Change only after telling Nithesh and Swetha."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import pandas as pd

SOURCES = ("power", "imerg", "smap", "merra2", "modis")

# Every per-source daily frame has these columns. A source fills what it provides; the rest stay NaN.
DAILY_COLUMNS = [
    "date",          # datetime64[ns], one row per day
    "rain_mm",       # POWER, IMERG
    "temp_mean_c",   # POWER, MERRA-2
    "temp_max_c",    # POWER, MERRA-2
    "solar_mj_m2",   # POWER
    "rh_pct",        # POWER
    "wind_ms",       # POWER
    "soil_moisture", # SMAP, MERRA-2 (m3/m3, kept per source so disagreement stays visible)
]


class SourceUnavailable(Exception):
    """A source could not be fetched (network, login, missing data)."""


@dataclass
class SourceMeta:
    source: str
    status: str = "unavailable"   # "ok" | "fallback" | "unavailable"
    dataset: str = ""
    version: str = ""
    start: str | None = None
    end: str | None = None
    grid_lat: float | None = None
    grid_lon: float | None = None
    fetched_at: str | None = None
    cache_hit: bool = False
    is_fallback: bool = False
    note: str = ""


@dataclass
class FeatureBundle:
    lat: float
    lon: float
    daily: dict[str, pd.DataFrame]       # one frame per source (NOT merged)
    meta: dict[str, SourceMeta]

    def available(self) -> list[str]:
        return [s for s, m in self.meta.items() if m.status != "unavailable" and s in self.daily]

    def meta_dict(self) -> dict:
        return {s: asdict(m) for s, m in self.meta.items()}


def empty_daily() -> pd.DataFrame:
    return pd.DataFrame({c: pd.Series(dtype="float64") for c in DAILY_COLUMNS}).astype({"date": "datetime64[ns]"})
