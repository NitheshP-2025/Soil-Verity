"""NASA POWER daily point data (REST, no login). Backbone for the 20-year history.

VERIFY before relying on it: parameter names, units (esp. solar) and the -999 fill value
against https://power.larc.nasa.gov/docs/
"""
from __future__ import annotations
import numpy as np
import pandas as pd
import requests
from .. import config
from ..schema import DAILY_COLUMNS, SourceUnavailable

URL = "https://power.larc.nasa.gov/api/temporal/daily/point"
PARAMS = {
    "T2M": "temp_mean_c",
    "T2M_MAX": "temp_max_c",
    "PRECTOTCORR": "rain_mm",
    "ALLSKY_SFC_SW_DWN": "solar_mj_m2",
    "RH2M": "rh_pct",
    "WS2M": "wind_ms",
}
FILL = -999.0


def parse_power_json(payload: dict) -> pd.DataFrame:
    """Turn a POWER JSON payload into the shared daily schema (pure function, testable offline)."""
    try:
        block = payload["properties"]["parameter"]
    except (KeyError, TypeError) as e:
        raise SourceUnavailable(f"Unexpected POWER response shape: {e}")
    frames = {}
    for api_name, col in PARAMS.items():
        if api_name in block:
            frames[col] = pd.Series(block[api_name])
    if not frames:
        raise SourceUnavailable("POWER response had none of the expected parameters")
    df = pd.DataFrame(frames)
    df.index = pd.to_datetime(df.index, format="%Y%m%d")
    df = df.replace(FILL, np.nan).sort_index()
    df.index.name = "date"
    df = df.reset_index()
    for c in DAILY_COLUMNS:
        if c not in df:
            df[c] = np.nan
    return df[DAILY_COLUMNS]


def fetch(lat: float, lon: float, start_year: int, end_year: int) -> pd.DataFrame:
    params = {
        "parameters": ",".join(PARAMS),
        "community": "AG",
        "latitude": lat,
        "longitude": lon,
        "start": f"{start_year}0101",
        "end": f"{end_year}1231",
        "format": "JSON",
    }
    try:
        r = requests.get(URL, params=params, timeout=config.REQUEST_TIMEOUT_S)
        r.raise_for_status()
        return parse_power_json(r.json())
    except requests.RequestException as e:
        raise SourceUnavailable(f"POWER request failed: {e}")
