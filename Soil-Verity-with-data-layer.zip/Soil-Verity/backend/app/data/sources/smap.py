"""SMAP L4 (soil moisture). TODO (Bala).

Plan: earthaccess login + search SPL4SMGP; open with xarray, select nearest grid cell, aggregate 3-hourly to daily; fill soil_moisture.
Never cache whole granules: subset to the point, then cache the small result.
VERIFY current collection short names and versions in NASA Earthdata search first.
"""
from __future__ import annotations
import pandas as pd
from ..schema import SourceUnavailable


def fetch(lat: float, lon: float, start_year: int, end_year: int) -> pd.DataFrame:
    raise SourceUnavailable("smap fetcher not implemented yet")
