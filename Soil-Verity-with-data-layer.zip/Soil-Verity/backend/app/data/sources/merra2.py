"""MERRA-2 (second soil-moisture source, temperature). TODO (Bala).

Plan: earthaccess search a MERRA-2 land/surface collection; select point; fill soil_moisture, temp_mean_c, temp_max_c. Check lon convention.
Never cache whole granules: subset to the point, then cache the small result.
VERIFY current collection short names and versions in NASA Earthdata search first.
"""
from __future__ import annotations
import pandas as pd
from ..schema import SourceUnavailable


def fetch(lat: float, lon: float, start_year: int, end_year: int) -> pd.DataFrame:
    raise SourceUnavailable("merra2 fetcher not implemented yet")
