"""MODIS greenness (optional). TODO (Bala).

Plan: optional; return NotImplemented-style SourceUnavailable until time allows.
Never cache whole granules: subset to the point, then cache the small result.
VERIFY current collection short names and versions in NASA Earthdata search first.
"""
from __future__ import annotations
import pandas as pd
from ..schema import SourceUnavailable


def fetch(lat: float, lon: float, start_year: int, end_year: int) -> pd.DataFrame:
    raise SourceUnavailable("modis fetcher not implemented yet")
