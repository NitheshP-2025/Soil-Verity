"""Data layer entry point (owner: Bala).  Usage:

    from app.data import get_features
    bundle = get_features(10.78, 79.14, start_year=2005, end_year=2024)
    bundle.daily["power"], bundle.meta["imerg"].status, ...

Per-source frames are NOT merged: Nithesh's engine re-runs scoring per source.
Set use_fixture=True to get deterministic synthetic data (flagged is_fallback) before NASA wiring is done.
"""
from __future__ import annotations
from datetime import datetime, timezone
from . import cache, config, fallback
from .schema import FeatureBundle, SourceMeta, SourceUnavailable, SOURCES
from .sources import power, imerg, smap, merra2, modis

_FETCHERS = {"power": power.fetch, "imerg": imerg.fetch, "smap": smap.fetch, "merra2": merra2.fetch, "modis": modis.fetch}
_DEFAULT_SOURCES = ("power", "imerg", "smap", "merra2")


def get_features(lat: float, lon: float, start_year: int | None = None, end_year: int | None = None,
                 sources: tuple[str, ...] = _DEFAULT_SOURCES, offline: bool = False,
                 use_fixture: bool = False, cache_root=None) -> FeatureBundle:
    start_year = start_year or config.DEFAULT_START_YEAR
    end_year = end_year or datetime.now(timezone.utc).year - 1
    daily, meta = {}, {}
    for s in sources:
        if s not in SOURCES:
            raise ValueError(f"unknown source {s}")
        glat, glon = cache.snapped_point(s, lat, lon)
        m = SourceMeta(source=s, grid_lat=glat, grid_lon=glon, start=str(start_year), end=str(end_year))
        if use_fixture:
            try:
                daily[s] = fallback.synthetic_daily(s, start_year, end_year)
                m.status, m.is_fallback, m.note = "fallback", True, "synthetic fixture, not real data"
            except ValueError:
                m.note = "no fixture for this source"
            meta[s] = m
            continue
        df = cache.read(s, lat, lon, start_year, end_year, cache_root)
        if df is not None:
            m.cache_hit = True
        elif not offline:
            try:
                df = _FETCHERS[s](glat, glon, start_year, end_year)
                cache.write(df, s, lat, lon, start_year, end_year, cache_root)
                m.fetched_at = datetime.now(timezone.utc).isoformat()
            except SourceUnavailable as e:
                m.note = str(e)
        else:
            m.note = "offline and not cached"
        if df is not None:
            daily[s], m.status = df, "ok"
        meta[s] = m
    return FeatureBundle(lat=lat, lon=lon, daily=daily, meta=meta)
