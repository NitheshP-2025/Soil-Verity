"""Deterministic synthetic data so teammates can build before NASA data is wired up.
Sources deliberately DISAGREE (IMERG wetter, MERRA-2 biased) so Solid/Mixed/Fragile logic can be tested.
Always flagged is_fallback=True. Never present this as real data."""
from __future__ import annotations
import numpy as np
import pandas as pd
from .schema import DAILY_COLUMNS


def synthetic_daily(source: str, start_year: int, end_year: int, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.date_range(f"{start_year}-01-01", f"{end_year}-12-31", freq="D")
    doy = dates.dayofyear.to_numpy()
    # NE-monsoon-like peak around Nov plus a weaker SW peak
    p_rain = 0.08 + 0.35 * np.exp(-((doy - 315) / 35.0) ** 2) + 0.1 * np.exp(-((doy - 180) / 40.0) ** 2)
    base_rain = np.where(rng.random(len(dates)) < p_rain, rng.gamma(1.6, 11.0, len(dates)), 0.0)
    temp = 28 + 4 * np.sin((doy - 100) / 365 * 2 * np.pi) + rng.normal(0, 0.8, len(dates))
    sm_base = pd.Series(base_rain).rolling(20, min_periods=1).mean().to_numpy() / 25 + 0.12

    df = pd.DataFrame({c: np.nan for c in DAILY_COLUMNS}, index=range(len(dates)))
    df["date"] = dates
    if source == "power":
        df["rain_mm"], df["temp_mean_c"], df["temp_max_c"] = base_rain, temp, temp + 5
        df["solar_mj_m2"], df["rh_pct"], df["wind_ms"] = 18.0, 70.0, 2.5
    elif source == "imerg":
        df["rain_mm"] = base_rain * 1.25 + rng.normal(0, 1.0, len(dates)).clip(0)
    elif source == "smap":
        df["soil_moisture"] = sm_base
    elif source == "merra2":
        df["soil_moisture"] = sm_base * 0.8 + 0.05
        df["temp_mean_c"], df["temp_max_c"] = temp - 0.7, temp + 4
    else:
        raise ValueError(f"no synthetic data for {source}")
    return df[DAILY_COLUMNS]
