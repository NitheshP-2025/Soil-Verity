"""Derived features from per-source daily frames: monthly summaries, extreme events, disagreement."""
from __future__ import annotations
import numpy as np
import pandas as pd
from . import config


def monthly_summary(daily: pd.DataFrame) -> pd.DataFrame:
    d = daily.copy()
    d["year"], d["month"] = d["date"].dt.year, d["date"].dt.month
    g = d.groupby(["year", "month"])
    out = pd.DataFrame({
        "rain_mm_sum": g["rain_mm"].sum(min_count=1),
        "temp_mean_c": g["temp_mean_c"].mean(),
        "temp_max_c_mean": g["temp_max_c"].mean(),
        "soil_moisture_mean": g["soil_moisture"].mean(),
    })
    return out.reset_index()


def _longest_run(mask: np.ndarray) -> int:
    best = cur = 0
    for v in mask:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return best


def extreme_events(daily: pd.DataFrame) -> pd.DataFrame:
    """Per year: heat days, heavy-rain days, longest dry spell (thresholds in config)."""
    rows = []
    for year, g in daily.groupby(daily["date"].dt.year):
        rows.append({
            "year": int(year),
            "heat_days": int((g["temp_max_c"] >= config.HEAT_DAY_TMAX_C).sum()),
            "heavy_rain_days": int((g["rain_mm"] >= config.HEAVY_RAIN_DAY_MM).sum()),
            "longest_dry_spell_days": _longest_run((g["rain_mm"] < config.DRY_DAY_MM).to_numpy()),
        })
    return pd.DataFrame(rows, columns=["year", "heat_days", "heavy_rain_days", "longest_dry_spell_days"])


def annual_rain_disagreement(a: pd.DataFrame, b: pd.DataFrame) -> pd.DataFrame:
    """Relative difference in yearly rainfall between two sources (e.g. POWER vs IMERG)."""
    ya = a.groupby(a["date"].dt.year)["rain_mm"].sum(min_count=1)
    yb = b.groupby(b["date"].dt.year)["rain_mm"].sum(min_count=1)
    df = pd.concat({"a_mm": ya, "b_mm": yb}, axis=1).dropna()
    df["rel_diff"] = (df["b_mm"] - df["a_mm"]) / df["a_mm"]
    df.index.name = "year"
    return df.reset_index()
