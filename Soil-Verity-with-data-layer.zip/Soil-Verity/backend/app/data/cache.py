"""Parquet cache keyed by (source, snapped lat/lon, year range)."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
from . import config


def snap(value: float, step: float) -> float:
    return round(round(value / step) * step, 4)


def snapped_point(source: str, lat: float, lon: float) -> tuple[float, float]:
    step = config.GRID_STEP[source]
    return snap(lat, step), snap(lon, step)


def cache_path(source: str, lat: float, lon: float, start_year: int, end_year: int, root: Path | None = None) -> Path:
    glat, glon = snapped_point(source, lat, lon)
    root = Path(root) if root else config.CACHE_DIR
    return root / source / f"{glat:+.4f}_{glon:+.4f}_{start_year}_{end_year}.parquet"


def read(source, lat, lon, start_year, end_year, root=None) -> pd.DataFrame | None:
    p = cache_path(source, lat, lon, start_year, end_year, root)
    return pd.read_parquet(p) if p.exists() else None


def write(df: pd.DataFrame, source, lat, lon, start_year, end_year, root=None) -> Path:
    p = cache_path(source, lat, lon, start_year, end_year, root)
    p.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(p, index=False)
    return p
