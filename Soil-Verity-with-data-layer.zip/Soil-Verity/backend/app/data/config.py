"""Data-layer settings. Anything the team must agree on lives here, not in code."""
import os
from pathlib import Path

CACHE_DIR = Path(os.getenv("TERRALOOP_CACHE_DIR", Path(__file__).resolve().parents[3] / ".cache"))
DEFAULT_START_YEAR = 2005          # ~20-year climate picture
REQUEST_TIMEOUT_S = 60
EARTHDATA_USERNAME = os.getenv("EARTHDATA_USERNAME")
EARTHDATA_PASSWORD = os.getenv("EARTHDATA_PASSWORD")

# Grid step (degrees) used to snap a farm location so nearby farms share one cache file.
# VERIFY each against the dataset docs before relying on them.
GRID_STEP = {"power": 0.5, "imerg": 0.1, "smap": 0.09, "merra2": 0.5, "modis": 0.05}

# Extreme-event thresholds. PLACEHOLDERS: agree with Nithesh/Jagadeesh and cite local guidance.
HEAT_DAY_TMAX_C = 38.0
HEAVY_RAIN_DAY_MM = 64.5
DRY_DAY_MM = 2.5
